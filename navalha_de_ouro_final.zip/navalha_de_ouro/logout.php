<?php
require_once __DIR__ . '/config/conexao.php';
session_start();
session_unset();
session_destroy();
header('Location: index.php');
exit;
