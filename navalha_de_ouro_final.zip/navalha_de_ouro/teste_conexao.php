<?php
require_once __DIR__ . '/config/conexao.php';
echo "Conectado com sucesso ao banco barbearia!";
