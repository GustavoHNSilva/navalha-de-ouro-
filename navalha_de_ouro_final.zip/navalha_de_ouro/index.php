<?php
require_once __DIR__ . '/config/conexao.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Navalha de Ouro — Home</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="icon" href="img/logo.png">
  <meta name="description" content="Barbearia Navalha de Ouro — cortes, barbas e estilo em São Paulo.">
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <a href="index.php" class="logo">
        <img src="img/logo.png" alt="Navalha de Ouro"/>
        <span class="brand">Navalha de Ouro</span>
      </a>
      <nav class="nav" id="main-nav">
        <a href="index.php">Home</a>
        <a href="sobre.php">Sobre</a>
        <a href="servicos.php">Serviços</a>
        <a href="contato.php">Contato</a>
        <a href="agendamento.php" class="btn agendar">Agendamento</a>
        <a href="meus_agendamentos.php">Meus Agendamentos</a>
        <a href="login.php">Login/Cadastrar</a>
        <a href="logout.php">Sair</a>
      </nav>
      <button class="nav-toggle" aria-label="Abrir menu" id="nav-toggle">☰</button>
    </div>
  </header>

  <main>
    <section class="hero">
      <div class="container hero-inner">
        <div class="hero-text">
          <h1>Barbearia Navalha de Ouro</h1>
          <p>Tradição, estilo e cuidado no coração de São Paulo. Corte, barba e atendimento personalizado.</p>
          <a href="agendamento.php" class="botao-principal">Agendar Agora</a>
        </div>
        <div class="hero-image" aria-hidden="true"></div>
      </div>
    </section>

    <section class="sobre-preview container">
      <h2>Quem somos</h2>
      <p>Na Navalha de Ouro, combinamos técnicas tradicionais com tendências contemporâneas para oferecer o melhor para nossos clientes. Atendimento personalizado e profissionais qualificados.</p>
      <a href="sobre.php" class="botao-secundario">Saiba Mais</a>
    </section>

    <section class="servicos-preview container">
      <h2>Serviços</h2>
      <div class="cards">
        <div class="card-servico">
          <h3>Corte Masculino</h3>
          <p>Modelo, máquina ou navalha. Corte personalizado.</p>
          <span class="preco">R$ 60,00</span>
        </div>
        <div class="card-servico">
          <h3>Barba</h3>
          <p>Raspagem, acabamento e tratamento de pele.</p>
          <span class="preco">R$ 40,00</span>
        </div>
        <div class="card-servico">
          <h3>Combo Corte + Barba</h3>
          <p>Pacote com desconto e finalização caprichada.</p>
          <span class="preco">R$ 90,00</span>
        </div>
      </div>
      <a href="servicos.php" class="botao-secundario">Ver todos os serviços</a>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-inner">
      <div class="footer-col">
        <h4>Navalha de Ouro</h4>
        <p>R. da Fonte, São Paulo — SP</p>
        <p>Telefone: (11) 9XXXX-XXXX</p>
      </div>
      <div class="footer-col">
        <h4>Links</h4>
        <a href="sobre.php">Sobre</a>
        <a href="servicos.php">Serviços</a>
        <a href="contato.php">Contato</a>
      </div>
      <div class="footer-col">
        <h4>Siga-nos</h4>
        <p>Instagram • Facebook</p>
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">© <span id="ano"></span> Navalha de Ouro — Todos os direitos reservados</div>
    </div>
  </footer>

  <script src="js/main.js"></script>
</body>
</html>
