<?php
require_once __DIR__ . '/config/conexao.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
error_reporting(E_ALL);
ini_set('display_errors', 1);

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['senha'])) {
  $email = trim($_POST['email']);
  $senha = $_POST['senha'];

  $sql = "SELECT id, nome, email, senha FROM clientes WHERE email = ?";
  $stmt = $conn->prepare($sql);
  if (!$stmt) {
    $erro = "Erro ao preparar consulta: " . $conn->error;
  } else {
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
      if (password_verify($senha, $row['senha'])) {
        $_SESSION['usuario'] = [
          'id'    => $row['id'],
          'nome'  => $row['nome'],
          'email' => $row['email']
        ];
        header('Location: index.php');
        exit;
      } else {
        $erro = "E-mail ou senha inválidos.";
      }
    } else {
      $erro = "E-mail ou senha inválidos.";
    }
  }
}
?>
<?php if (!empty($erro)): ?>
  <p class="erro"><?php echo htmlspecialchars($erro); ?></p>
<?php endif; ?>

<!doctype html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login — Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <main class="container">
    <h1>Login</h1>
    <form method="post">
      <label>E-mail <input type="email" name="email" required></label>
      <label>Senha <input type="password" name="senha" required></label>
      <button type="submit" class="botao-principal">Entrar</button>
    </form>
    <p>Não tem conta? <a href="cadastro.php">Cadastre-se</a></p>
  </main>
</body>

</html>