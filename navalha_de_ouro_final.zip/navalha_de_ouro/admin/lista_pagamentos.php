<?php
require_once __DIR__ . '/../config/auth_funcionario.php';

if ($funcionario['tipo'] !== 'admin') {
    die('Acesso restrito ao administrador.');
}

$sql = "SELECT p.id, p.metodo, p.valor, p.status, p.data_pagamento,
               a.data_hora,
               c.nome AS cliente,
               s.nome AS servico
        FROM pagamentos p
        JOIN agendamentos a ON a.id = p.agendamento_id
        JOIN clientes c ON c.id = a.cliente_id
        JOIN servicos s ON s.id = a.servico_id
        ORDER BY p.data_pagamento DESC";

$result = $conn->query($sql);
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Pagamentos</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <main class="container">
    <h1>Pagamentos</h1>
    <nav>
      <a href="/admin/painel.php">Voltar ao painel</a>
    </nav>

    <table border="1" cellpadding="5">
      <tr>
        <th>ID</th>
        <th>Data Pagamento</th>
        <th>Cliente</th>
        <th>Serviço</th>
        <th>Valor</th>
        <th>Método</th>
        <th>Status</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo $row['data_pagamento'] ? date('d/m/Y H:i', strtotime($row['data_pagamento'])) : '-'; ?></td>
          <td><?php echo htmlspecialchars($row['cliente']); ?></td>
          <td><?php echo htmlspecialchars($row['servico']); ?></td>
          <td>R$ <?php echo number_format($row['valor'], 2, ',', '.'); ?></td>
          <td><?php echo htmlspecialchars($row['metodo']); ?></td>
          <td><?php echo htmlspecialchars($row['status']); ?></td>
        </tr>
      <?php endwhile; ?>
    </table>
  </main>
</body>
</html>
