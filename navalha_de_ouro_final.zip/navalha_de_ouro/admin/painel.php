<?php
require_once __DIR__ . '/../config/auth_funcionario.php';

if ($funcionario['tipo'] !== 'admin') {
    die('Acesso restrito ao administrador.');
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Painel do Admin</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <main class="container">
    <h1>Olá, <?php echo htmlspecialchars($funcionario['nome']); ?> (Admin)</h1>

    <nav>
      <a href="/admin/painel.php">Início</a> |
      <a href="/admin/lista_agendamentos.php">Agendamentos</a> |
      <a href="/admin/lista_pagamentos.php">Pagamentos</a> |
      <a href="/funcionario/logout.php">Sair</a>
    </nav>

    <p>Aqui você pode gerenciar a barbearia.</p>
  </main>
</body>
</html>
