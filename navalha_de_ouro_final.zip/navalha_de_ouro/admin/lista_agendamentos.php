<?php
require_once __DIR__ . '/../config/auth_funcionario.php';

if (!in_array($funcionario['tipo'], ['admin', 'recepcionista'])) {
    die('Acesso restrito.');
}

$sql = "SELECT a.id, a.data_hora, a.status,
               c.nome AS cliente,
               b.nome AS barbeiro,
               s.nome AS servico,
               s.preco,
               p.status AS status_pagamento
        FROM agendamentos a
        JOIN clientes c ON c.id = a.cliente_id
        JOIN barbeiros b ON b.id = a.barbeiro_id
        JOIN servicos s ON s.id = a.servico_id
        LEFT JOIN pagamentos p ON p.agendamento_id = a.id
        ORDER BY a.data_hora DESC";

$result = $conn->query($sql);
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Agendamentos</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <main class="container">
    <h1>Agendamentos</h1>
    <nav>
      <a href="/admin/painel.php">Voltar ao painel</a>
    </nav>

    <table border="1" cellpadding="5">
      <tr>
        <th>ID</th>
        <th>Data/Hora</th>
        <th>Cliente</th>
        <th>Barbeiro</th>
        <th>Serviço</th>
        <th>Valor</th>
        <th>Status</th>
        <th>Pagamento</th>
        <th>Ações</th>
      </tr>
      <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
          <td><?php echo $row['id']; ?></td>
          <td><?php echo date('d/m/Y H:i', strtotime($row['data_hora'])); ?></td>
          <td><?php echo htmlspecialchars($row['cliente']); ?></td>
          <td><?php echo htmlspecialchars($row['barbeiro']); ?></td>
          <td><?php echo htmlspecialchars($row['servico']); ?></td>
          <td>R$ <?php echo number_format($row['preco'], 2, ',', '.'); ?></td>
          <td><?php echo htmlspecialchars($row['status']); ?></td>
          <td><?php echo $row['status_pagamento'] ?: 'sem registro'; ?></td>
          <td>
            <?php if ($row['status'] === 'concluido' && !$row['status_pagamento']): ?>
              <form action="/admin/registrar_pagamento.php" method="post" style="display:inline;">
                <input type="hidden" name="agendamento_id" value="<?php echo $row['id']; ?>">
                <input type="hidden" name="valor" value="<?php echo $row['preco']; ?>">
                <select name="metodo">
                  <option value="dinheiro">Dinheiro</option>
                  <option value="cartao">Cartão</option>
                  <option value="pix">Pix</option>
                </select>
                <button type="submit">Registrar pagamento</button>
              </form>
            <?php else: ?>
              -
            <?php endif; ?>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </main>
</body>
</html>
