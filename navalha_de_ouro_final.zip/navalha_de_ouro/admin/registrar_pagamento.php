<?php
require_once __DIR__ . '/../config/auth_funcionario.php';

if (!in_array($funcionario['tipo'], ['admin', 'recepcionista'])) {
    die('Acesso restrito.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $agendamento_id = (int) ($_POST['agendamento_id'] ?? 0);
    $metodo         = $_POST['metodo'] ?? '';
    $valor          = (float) ($_POST['valor'] ?? 0);

    if ($agendamento_id <= 0 || !in_array($metodo, ['dinheiro', 'cartao', 'pix'])) {
        die('Dados inválidos.');
    }

    $sql = "INSERT INTO pagamentos (agendamento_id, metodo, valor, status, data_pagamento)
            VALUES (?, ?, ?, 'pago', NOW())";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Erro no prepare: " . $conn->error);
    }

    $stmt->bind_param("isd", $agendamento_id, $metodo, $valor);

    if ($stmt->execute()) {
        header('Location: /admin/lista_agendamentos.php');
        exit;
    } else {
        die("Erro ao registrar pagamento: " . $stmt->error);
    }
} else {
    header('Location: /admin/lista_agendamentos.php');
    exit;
}
