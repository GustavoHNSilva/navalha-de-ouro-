<?php
require_once __DIR__ . '/config/auth_cliente.php';
require_once __DIR__ . '/config/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8');

// ID do cliente logado
$id_cliente = $_SESSION['usuario']['id'] ?? null;

if (!$id_cliente) {
    header('Location: login.php');
    exit;
}

// ---------- PROCESSA CANCELAMENTO ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cancelar') {
    $id_agendamento = $_POST['id_agendamento'] ?? null;

    if ($id_agendamento) {
        // Só cancela agendamento que é do próprio cliente e ainda está 'agendado'
        $sqlCancelar = "
            UPDATE agendamentos
            SET status = 'cancelado'
            WHERE id = ? 
              AND cliente_id = ?
              AND status = 'agendado'
        ";

        try {
            $stmt = $conn->prepare($sqlCancelar);
            $stmt->bind_param('ii', $id_agendamento, $id_cliente);
            $stmt->execute();

            if ($stmt->affected_rows > 0) {
                echo "
                    <script>
                        alert('Agendamento cancelado com sucesso.');
                        window.location.href = 'meus_agendamentos.php';
                    </script>
                ";
                exit;
            } else {
                echo "
                    <script>
                        alert('Não foi possível cancelar este agendamento. Verifique se ele ainda está pendente.');
                        window.location.href = 'meus_agendamentos.php';
                    </script>
                ";
                exit;
            }
        } catch (Exception $e) {
            echo "
                <script>
                    alert('Erro ao cancelar agendamento: " . addslashes($e->getMessage()) . "');
                    window.location.href = 'meus_agendamentos.php';
                </script>
            ";
            exit;
        }
    } else {
        echo "
            <script>
                alert('Agendamento inválido.');
                window.location.href = 'meus_agendamentos.php';
            </script>
        ";
        exit;
    }
}

// ---------- BUSCA AGENDAMENTOS PENDENTES DO CLIENTE ----------
$sql = "
    SELECT 
        a.id,
        a.data_hora,
        a.status,
        s.nome AS servico,
        b.nome AS barbeiro
    FROM agendamentos a
    INNER JOIN servicos s  ON a.servico_id  = s.id
    INNER JOIN barbeiros b ON a.barbeiro_id = b.id
    WHERE a.cliente_id = ?
      AND a.status = 'agendado'
    ORDER BY a.data_hora ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_cliente);
$stmt->execute();
$result = $stmt->get_result();

$agendamentos = [];
while ($row = $result->fetch_assoc()) {
    $agendamentos[] = $row;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meus Agendamentos - Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <header class="site-header container">
    <h1>Meus Agendamentos</h1>
    <nav>
      <a href="index.php">Página Inicial</a>
      <a href="agendamento.php">Novo Agendamento</a>
      <a href="meus_agendamentos.php">Meus Agendamentos</a>
      <a href="logout.php">Sair</a>
    </nav>
  </header>

  <main class="container">
    <h2>Agendamentos pendentes</h2>

    <?php if (empty($agendamentos)): ?>
      <p>Você não possui agendamentos pendentes.</p>
    <?php else: ?>
      <table class="tabela-agendamentos">
        <thead>
          <tr>
            <th>Data</th>
            <th>Hora</th>
            <th>Serviço</th>
            <th>Profissional</th>
            <th>Status</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($agendamentos as $ag): ?>
            <?php
              $dataHora = new DateTime($ag['data_hora']);
              $data = $dataHora->format('d/m/Y');
              $hora = $dataHora->format('H:i');
            ?>
            <tr>
              <td><?= $data ?></td>
              <td><?= $hora ?></td>
              <td><?= htmlspecialchars($ag['servico'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= htmlspecialchars($ag['barbeiro'], ENT_QUOTES, 'UTF-8') ?></td>
              <td><?= ucfirst($ag['status']) ?></td>
              <td>
                <form action="meus_agendamentos.php" method="post" onsubmit="return confirm('Tem certeza que deseja cancelar este agendamento?');">
                  <input type="hidden" name="acao" value="cancelar">
                  <input type="hidden" name="id_agendamento" value="<?= (int)$ag['id'] ?>">
                  <button type="submit" class="botao-principal botao-cancelar">Cancelar</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>

  </main>

  <footer class="site-footer container">
    © <?= date('Y') ?> Navalha de Ouro
  </footer>

  <script src="js/main.js"></script>
</body>

</html>
