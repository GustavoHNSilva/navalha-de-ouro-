<?php
require_once __DIR__ . '/config/auth_cliente.php';
require_once __DIR__ . '/config/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Garante exceptions do mysqli
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8');

// Carrega serviços do banco
$servicos = [];
$res = $conn->query("SELECT id, nome, preco FROM servicos WHERE ativo = 1");
if ($res) {
  while ($row = $res->fetch_assoc()) {
    $servicos[] = $row;
  }
}

// Carrega barbeiros do banco
$profissionais = [];
$res = $conn->query("SELECT id, nome FROM barbeiros WHERE ativo = 1");
if ($res) {
  while ($row = $res->fetch_assoc()) {
    $profissionais[] = $row;
  }
}

// ID do cliente logado (ajuste aqui se seu auth_cliente usar outro índice)
$id_cliente = $_SESSION['usuario']['id'] ?? null;

// PROCESSA O FORMULÁRIO
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  $data_agendamento = $_POST['data_agendamento'] ?? null;
  $hora_agendamento = $_POST['hora_agendamento'] ?? null;
  $id_servico = $_POST['servico'] ?? null;
  $id_barbeiro = $_POST['profissional'] ?? null;

  if (!$id_cliente || !$data_agendamento || !$hora_agendamento || !$id_servico || !$id_barbeiro) {
    echo "<script>alert('Preencha todos os campos antes de confirmar o agendamento.'); history.back();</script>";
    exit;
  }

  // Monta o DATETIME conforme a base: coluna data_hora (YYYY-MM-DD HH:MM:SS)
  $data_hora = $data_agendamento . ' ' . $hora_agendamento . ':00';

  /*
      Base real (schema.sql):

      CREATE TABLE agendamentos (
          id INT AUTO_INCREMENT PRIMARY KEY,
          cliente_id INT NOT NULL,
          barbeiro_id INT NOT NULL,
          servico_id INT NOT NULL,
          data_hora DATETIME NOT NULL,
          status ENUM('agendado','concluido','cancelado') NOT NULL DEFAULT 'agendado',
          observacoes TEXT,
          criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          ...
      );

      Então o INSERT correto é nesses campos: cliente_id, barbeiro_id, servico_id, data_hora
  */

  $sql = "INSERT INTO agendamentos (cliente_id, barbeiro_id, servico_id, data_hora)
            VALUES (?, ?, ?, ?)";

  try {
    $stmt = $conn->prepare($sql);
    // iiis = int, int, int, string (DATETIME)
    $stmt->bind_param("iiis", $id_cliente, $id_barbeiro, $id_servico, $data_hora);
    $stmt->execute();

    echo "
            <script>
                alert('Agendamento realizado com sucesso para {$data_agendamento} às {$hora_agendamento}!');
                window.location.href = 'index.php';
            </script>
        ";
    exit;
  } catch (Exception $e) {
    echo "<script>alert('Erro ao salvar agendamento: " . addslashes($e->getMessage()) . "');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agendar Horário - Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>

  <header class="site-header container">
    <h1>Agendar Horário</h1>
    <nav>
      <a href="index.php">Página Inicial</a>
      <a href="meus_agendamentos.php">Meus Agendamentos</a>
      <a href="logout.php">Sair</a>
    </nav>
  </header>

  <main class="container">

    <h2>Selecione o serviço e o profissional</h2>

    <form action="agendamento.php" method="post" class="form-agendamento">

      <label for="servico">Serviço</label>
      <select name="servico" id="servico" required>
        <option value="">Selecione...</option>
        <?php foreach ($servicos as $s): ?>
          <option value="<?= $s['id'] ?>">
            <?= htmlspecialchars($s['nome'], ENT_QUOTES, 'UTF-8') ?>
            - R$ <?= number_format($s['preco'], 2, ',', '.') ?>
          </option>
        <?php endforeach; ?>
      </select>

      <label for="profissional">Profissional</label>
      <!-- IMPORTANTE: name="profissional" para bater com o PHP -->
      <select name="profissional" id="profissional" required>
        <option value="">Selecione...</option>
        <?php foreach ($profissionais as $p): ?>
          <option value="<?= $p['id'] ?>">
            <?= htmlspecialchars($p['nome'], ENT_QUOTES, 'UTF-8') ?>
          </option>
        <?php endforeach; ?>
      </select>

      <label for="data_agendamento">Data</label>
      <input type="date" name="data_agendamento" id="data_agendamento" required>

      <label for="hora_agendamento">Horário</label>
      <input type="time" name="hora_agendamento" id="hora_agendamento" required>

      <?php if (!isset($_SESSION['usuario'])): ?>
        <p>Para confirmar, por favor <a href="login.php">Login / Cadastrar</a>.</p>
      <?php endif; ?>

      <button type="submit" class="botao-principal">Confirmar agendamento</button>
    </form>
  </main>

  <footer class="site-footer container">© <?php echo date('Y'); ?> Navalha de Ouro</footer>

  <script src="js/main.js"></script>
</body>

</html>