<?php
require_once __DIR__ . '/config/auth_cliente.php';
require_once __DIR__ . '/config/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

if (!isset($_SESSION['usuario'])) {
  header('Location: login.php');
  exit;
}

$usuario = $_SESSION['usuario'];
$agendamentos = [];

$sql = "SELECT a.data_hora, a.status,
               s.nome AS servico,
               b.nome AS barbeiro
        FROM agendamentos a
        JOIN servicos s  ON s.id = a.servico_id
        JOIN barbeiros b ON b.id = a.barbeiro_id
        WHERE a.cliente_id = ?
        ORDER BY a.data_hora DESC";

$stmt = $conn->prepare($sql);
if ($stmt) {
  $stmt->bind_param("i", $usuario['id']);
  $stmt->execute();
  $result = $stmt->get_result();
  while ($row = $result->fetch_assoc()) {
    $agendamentos[] = $row;
  }
}
?>

<!doctype html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Painel — Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <main class="container">
    <h1>Olá, <?php echo htmlspecialchars($usuario['nome']); ?></h1>
    <a href="logout.php" class="botao-secundario">Sair</a>
    <h2>Meus agendamentos</h2>
    <?php if (empty($agendamentos)): ?>
      <p>Você não tem agendamentos.</p>
    <?php else: ?>
      <ul class="lista-agendamentos">
        <?php foreach ($agendamentos as $a): ?>
          <li>
            <?php
            echo htmlspecialchars($a['servico']) .
              ' com ' . htmlspecialchars($a['barbeiro']) .
              ' — ' . date('d/m/Y H:i', strtotime($a['data_hora'])) .
              ' (' . htmlspecialchars($a['status']) . ')';
            ?>
          </li>

        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

  </main>
</body>

</html>