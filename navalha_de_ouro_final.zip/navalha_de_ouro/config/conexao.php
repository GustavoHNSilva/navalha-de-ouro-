<?php
$host    = getenv('DB_HOST') ?: '127.0.0.1';
$usuario = getenv('DB_USER') ?: 'root';
$senha   = getenv('DB_PASS') ?: '';
$banco   = getenv('DB_NAME') ?: 'barbearia';

$conn = new mysqli($host, $usuario, $senha, $banco);

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if (!$conn->set_charset("utf8mb4")) {
    die("Erro ao definir charset: " . $conn->error);
}
