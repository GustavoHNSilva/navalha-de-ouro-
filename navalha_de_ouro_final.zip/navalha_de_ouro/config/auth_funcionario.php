<?php
require_once __DIR__ . '/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['funcionario'])) {
    header('Location: /funcionario/login.php');
    exit;
}

$funcionario = $_SESSION['funcionario'];
