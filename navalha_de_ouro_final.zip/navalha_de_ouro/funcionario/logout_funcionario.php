<?php
session_start();
unset($_SESSION['funcionario']);
header('Location: login_funcionario.php');
exit;
