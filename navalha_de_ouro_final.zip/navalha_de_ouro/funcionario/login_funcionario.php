<?php
require_once "conexao.php";
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['senha'])) {
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];

    $sql = "SELECT id, nome, email, senha, tipo FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        $erro = "Erro ao preparar consulta: " . $conn->error;
    } else {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            if (password_verify($senha, $row['senha'])) {
                // guarda funcionário separado do cliente
                $_SESSION['funcionario'] = [
                    'id'    => $row['id'],
                    'nome'  => $row['nome'],
                    'email' => $row['email'],
                    'tipo'  => $row['tipo'],
                ];

                // redireciona conforme o tipo
                if ($row['tipo'] === 'admin') {
                    header('Location: painel_admin.php');
                } elseif ($row['tipo'] === 'barbeiro') {
                    header('Location: painel_barbeiro.php');
                } else { // recepcionista etc.
                    header('Location: painel_recepcionista.php');
                }
                exit;
            } else {
                $erro = "E-mail ou senha inválidos.";
            }
        } else {
            $erro = "E-mail ou senha inválidos.";
        }
    }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Login Funcionário</title>
</head>
<body>
  <h1>Login Funcionário</h1>

  <?php if (!empty($erro)): ?>
    <p style="color:red;"><?php echo htmlspecialchars($erro); ?></p>
  <?php endif; ?>

  <form method="post">
    <label>E-mail:<br>
      <input type="email" name="email" required>
    </label><br><br>
    <label>Senha:<br>
      <input type="password" name="senha" required>
    </label><br><br>
    <button type="submit">Entrar</button>
  </form>
</body>
</html>
