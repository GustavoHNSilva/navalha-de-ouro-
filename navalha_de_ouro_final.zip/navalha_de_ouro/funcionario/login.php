<?php
require_once __DIR__ . '/../config/conexao.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['senha'])) {
    $email = trim($_POST['email']);
    $senha = $_POST['senha'];

    $sql = "SELECT id, nome, email, senha, tipo FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        $erro = "Erro ao preparar consulta: " . $conn->error;
    } else {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            if (password_verify($senha, $row['senha'])) {
                $_SESSION['funcionario'] = [
                    'id'    => $row['id'],
                    'nome'  => $row['nome'],
                    'email' => $row['email'],
                    'tipo'  => $row['tipo'],
                ];

                if ($row['tipo'] === 'admin') {
                    header('Location: /admin/painel.php');
                } elseif ($row['tipo'] === 'barbeiro') {
                    header('Location: /barbeiro/painel.php');
                } else {
                    header('Location: /admin/painel.php');
                }
                exit;
            } else {
                $erro = "E-mail ou senha inválidos.";
            }
        } else {
            $erro = "E-mail ou senha inválidos.";
        }
    }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Login Funcionário</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <main class="container">
    <h1>Login Funcionário</h1>

    <?php if (!empty($erro)): ?>
      <p style="color:red;"><?php echo htmlspecialchars($erro); ?></p>
    <?php endif; ?>

    <form method="post">
      <label>E-mail <input type="email" name="email" required></label>
      <label>Senha <input type="password" name="senha" required></label>
      <button type="submit" class="botao-principal">Entrar</button>
    </form>
  </main>
</body>
</html>
