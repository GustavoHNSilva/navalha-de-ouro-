<?php
require_once __DIR__ . '/config/conexao.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sobre — Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <a href="index.php" class="logo">
        <img src="img/logo.png" alt="Navalha de Ouro"/>
      </a>
      <nav class="nav">
        <a href="index.php">Home</a>
        <a href="sobre.php">Sobre</a>
        <a href="servicos.php">Serviços</a>
        <a href="contato.php">Contato</a>
        <a href="agendamento.php" class="btn agendar">Agendamento</a>
        <a href="login.php">Login/Cadastrar</a>
      </nav>
      <button class="nav-toggle" aria-label="Abrir menu">☰</button>
    </div>
  </header>

  <main class="container">
    <section class="sobre">
      <h1>Nossa História</h1>
      <p>A Navalha de Ouro nasceu da paixão pelo ofício e pelo cuidado com os detalhes. Nossa missão é proporcionar experiências memoráveis através de cortes e serviços de alta qualidade.</p>

      <h2>Missão</h2>
      <p>Oferecer atendimento humano e profissional, respeitando o estilo de cada cliente.</p>

      <h2>Equipe</h2>
      <div class="equipe-grid">
        <div class="membro">
          <img src="img/equipe1.jpg" alt="Barbeiro">
          <h3>João Silva</h3>
          <p>Barbeiro chefe — 10 anos de experiência.</p>
        </div>
        <div class="membro">
          <img src="img/equipe2.jpg" alt="Barbeiro">
          <h3>Marcos Alves</h3>
          <p>Especialista em navalha e estilos clássicos.</p>
        </div>
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container">© <span id="ano2"></span> Navalha de Ouro</div>
  </footer>

  <script src="js/main.js"></script>
</body>
</html>
