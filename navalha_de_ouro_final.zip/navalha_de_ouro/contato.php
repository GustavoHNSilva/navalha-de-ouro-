<?php
require_once __DIR__ . '/config/conexao.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contato — Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <a href="index.php" class="logo"><img src="img/logo.png" alt="Navalha de Ouro"></a>
      <nav class="nav">
        <a href="index.php">Home</a>
        <a href="sobre.php">Sobre</a>
        <a href="servicos.php">Serviços</a>
        <a href="contato.php">Contato</a>
        <a href="agendamento.php" class="btn agendar">Agendamento</a>
      </nav>
    </div>
  </header>

  <main class="container contato">
    <h1>Fale Conosco</h1>
    <form id="form-contato" action="#" method="post" novalidate>
      <label>Nome
        <input type="text" name="nome" required>
      </label>
      <label>E-mail
        <input type="email" name="email" required>
      </label>
      <label>Mensagem
        <textarea name="mensagem" rows="6" required></textarea>
      </label>
      <button type="submit" class="botao-principal">Enviar Mensagem</button>
    </form>

    <aside class="info-contato">
      <h2>Informações</h2>
      <p><strong>Endereço:</strong> R. da Fonte, São Paulo — SP</p>
      <p><strong>Telefone:</strong> (11) 9XXXX-XXXX</p>
      <p><strong>E-mail:</strong> contato@navalhadeouro.com</p>

      <h3>Localização</h3>
      <div class="mapa">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
      </div>
    </aside>
  </main>

  <footer class="site-footer">
    <div class="container">© <span id="ano3"></span> Navalha de Ouro</div>
  </footer>

  <script src="js/main.js"></script>
</body>
</html>
