<?php
require_once "conexao.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$nome = "Cliente Teste";
$telefone = "11999999999";
$email = "teste@exemplo.com";
$nascimento = "2000-01-01";

$sql = "INSERT INTO clientes (nome, telefone, email, data_nascimento)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Erro no prepare: " . $conn->error);
}

$stmt->bind_param("ssss", $nome, $telefone, $email, $nascimento);

if ($stmt->execute()) {
    echo "Inserido com sucesso! ID: " . $stmt->insert_id;
} else {
    echo "Erro ao inserir: " . $stmt->error;
}
