<?php
require_once "auth_funcionario.php";

// Apenas barbeiro ou admin pode concluir
if (!in_array($funcionario['tipo'], ['barbeiro', 'admin'])) {
    die('Acesso restrito.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: painel_barbeiro.php');
    exit;
}

$agendamento_id = (int) ($_POST['agendamento_id'] ?? 0);

if ($agendamento_id <= 0) {
    die('Agendamento inválido.');
}

// Se for barbeiro, garantimos que ele só conclui o que é dele
if ($funcionario['tipo'] === 'barbeiro') {
    $sql = "UPDATE agendamentos a
            JOIN barbeiros b ON b.id = a.barbeiro_id
            SET a.status = 'concluido'
            WHERE a.id = ? AND b.usuario_id = ? AND a.status = 'agendado'";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Erro no prepare: " . $conn->error);
    }
    $stmt->bind_param("ii", $agendamento_id, $funcionario['id']);
} else {
    // Admin pode concluir qualquer um
    $sql = "UPDATE agendamentos
            SET status = 'concluido'
            WHERE id = ? AND status = 'agendado'";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Erro no prepare: " . $conn->error);
    }
    $stmt->bind_param("i", $agendamento_id);
}

if ($stmt->execute()) {
    // Volta para o painel do barbeiro
    header('Location: painel_barbeiro.php');
    exit;
} else {
    die("Erro ao concluir atendimento: " . $stmt->error);
}
