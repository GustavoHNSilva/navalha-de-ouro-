<?php
require_once __DIR__ . '/../config/auth_funcionario.php';

if (!in_array($funcionario['tipo'], ['barbeiro', 'admin'])) {
    die('Acesso restrito a barbeiros.');
}

$sql = "SELECT id FROM barbeiros WHERE usuario_id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Erro no prepare: " . $conn->error);
}
$stmt->bind_param("i", $funcionario['id']);
$stmt->execute();
$result = $stmt->get_result();

if (!($row = $result->fetch_assoc())) {
    die('Seu usuário não está vinculado a nenhum barbeiro na tabela "barbeiros".');
}

$barbeiro_id = (int) $row['id'];

$sqlAg = "SELECT a.id,
                 a.data_hora,
                 a.status,
                 c.nome  AS cliente,
                 s.nome  AS servico,
                 s.preco AS valor
          FROM agendamentos a
          JOIN clientes c ON c.id = a.cliente_id
          JOIN servicos s ON s.id = a.servico_id
          WHERE a.barbeiro_id = ?
          ORDER BY a.data_hora ASC";

$stmtAg = $conn->prepare($sqlAg);
if (!$stmtAg) {
    die("Erro ao preparar consulta de agendamentos: " . $conn->error);
}
$stmtAg->bind_param("i", $barbeiro_id);
$stmtAg->execute();
$agendamentos = $stmtAg->get_result();
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Painel do Barbeiro</title>
  <link rel="stylesheet" href="/css/style.css">
</head>
<body>
  <main class="container">
    <h1>Olá, <?php echo htmlspecialchars($funcionario['nome']); ?> (<?php echo htmlspecialchars($funcionario['tipo']); ?>)</h1>

    <nav>
      <a href="/barbeiro/painel.php">Meus agendamentos</a> |
      <a href="/funcionario/logout.php">Sair</a>
    </nav>

    <h2>Meus agendamentos</h2>

    <?php if ($agendamentos->num_rows === 0): ?>
      <p>Você ainda não tem agendamentos.</p>
    <?php else: ?>
      <table border="1" cellpadding="5" cellspacing="0">
        <tr>
          <th>ID</th>
          <th>Data/Hora</th>
          <th>Cliente</th>
          <th>Serviço</th>
          <th>Valor</th>
          <th>Status</th>
          <th>Ação</th>
        </tr>
        <?php while ($ag = $agendamentos->fetch_assoc()): ?>
          <tr>
            <td><?php echo $ag['id']; ?></td>
            <td><?php echo date('d/m/Y H:i', strtotime($ag['data_hora'])); ?></td>
            <td><?php echo htmlspecialchars($ag['cliente']); ?></td>
            <td><?php echo htmlspecialchars($ag['servico']); ?></td>
            <td>R$ <?php echo number_format($ag['valor'], 2, ',', '.'); ?></td>
            <td><?php echo htmlspecialchars($ag['status']); ?></td>
            <td>
              <?php if ($ag['status'] === 'agendado'): ?>
                <form action="/barbeiro/concluir_atendimento.php" method="post" style="display:inline;">
                  <input type="hidden" name="agendamento_id" value="<?php echo $ag['id']; ?>">
                  <button type="submit">Concluir atendimento</button>
                </form>
              <?php elseif ($ag['status'] === 'concluido'): ?>
                Concluído
              <?php elseif ($ag['status'] === 'cancelado'): ?>
                Cancelado
              <?php else: ?>
                -
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      </table>
    <?php endif; ?>
  </main>
</body>
</html>
