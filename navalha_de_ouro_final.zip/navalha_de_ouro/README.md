# Navalha de Ouro

Sistema de agendamento para barbearia, desenvolvido em PHP com MySQL.

Este projeto está preparado para rodar tanto **localmente** (XAMPP, Laragon, etc.) quanto em **GitHub Codespaces**, usando a mesma base de código e o mesmo script SQL.

---

## Tecnologias

- PHP 8+
- MySQL/MariaDB
- HTML, CSS e JS
- GitHub Codespaces (opcional)

---

## Estrutura principal

- `index.php` – página inicial
- `config/conexao.php` – conexão com o banco de dados
- `sql/schema.sql` – script para criação do banco `barbearia`
- `teste_conexao.php` – script simples para testar a conexão
- pastas `admin/`, `funcionario/`, `barbeiro/` – áreas do sistema

---

## Banco de dados

O banco utilizado pelo sistema se chama **`barbearia`**.

O script de criação (tabelas, dados iniciais, etc.) está em:

```text
sql/schema.sql
```

---

## Variáveis de ambiente

O arquivo `config/conexao.php` utiliza as seguintes variáveis de ambiente (se existirem):

- `DB_HOST` – host do banco (padrão: `127.0.0.1`)
- `DB_USER` – usuário do banco (padrão: `root`)
- `DB_PASS` – senha do banco (padrão: vazio)
- `DB_NAME` – nome do banco (padrão: `barbearia`)

Se nenhuma variável for definida, os valores padrões acima são utilizados, o que é suficiente para a maioria dos ambientes locais (XAMPP/Laragon).

---

## Rodando localmente

### 1. Requisitos

- PHP instalado (ex.: via XAMPP, Wamp, Laragon)
- MySQL ou MariaDB rodando

### 2. Criar o banco e importar o schema

1. Crie um banco chamado `barbearia`.
2. Importe o arquivo `sql/schema.sql`:
   - Via phpMyAdmin (Importar → escolher o arquivo).
   - Ou via terminal:

     ```bash
     mysql -u root -p barbearia < sql/schema.sql
     ```

   Ajuste o usuário/senha conforme seu ambiente.

### 3. Verificar a conexão

Acesse o arquivo:

```text
teste_conexao.php
```

Se tudo estiver correto, ele deve exibir:

```text
Conectado com sucesso ao banco barbearia!
```

### 4. Rodar o servidor PHP (caso não use Apache)

Na pasta do projeto:

```bash
php -S localhost:8000
```

Depois, acesse no navegador:

```text
http://localhost:8000
```

---

## Rodando no GitHub Codespaces

### 1. Abrir o projeto no Codespaces

1. Suba este projeto para um repositório no GitHub.
2. No GitHub, clique em **Code** → aba **Codespaces** → **Create codespace on main**.

O Codespace vai abrir um VS Code no navegador dentro de um container configurado pelo arquivo `.devcontainer/devcontainer.json`.

### 2. O que o devcontainer faz

O arquivo `.devcontainer/devcontainer.json` está configurado para:

- Usar uma imagem base com PHP.
- Instalar o MariaDB (servidor MySQL) no container.
- Iniciar o serviço do banco.
- Criar o banco `barbearia`.
- Importar o script `sql/schema.sql` (se existir).
- Definir as variáveis de ambiente necessárias:

  - `DB_HOST=127.0.0.1`
  - `DB_USER=root`
  - `DB_PASS=` (vazio)
  - `DB_NAME=barbearia`

Assim, o código PHP consegue se conectar ao banco sem alteração extra.

### 3. Rodar o servidor no Codespaces

Depois que o Codespace terminar de criar o container:

1. Abra um terminal dentro do Codespace.
2. Vá até a pasta do projeto (caso ainda não esteja nela).
3. Rode:

   ```bash
   php -S 0.0.0.0:8000
   ```

4. O Codespaces vai oferecer um link (“Open in Browser”). Clique para abrir o sistema no navegador.

---

## Testando a conexão no Codespaces

No Codespaces, também é possível acessar:

```text
teste_conexao.php
```

Se a configuração do container estiver correta, você deverá ver:

```text
Conectado com sucesso ao banco barbearia!
```

---

## Ajustes

Se você quiser usar um usuário/senha diferente no MySQL (tanto local quanto no Codespaces), basta:

1. Ajustar o usuário/senha ao criar o banco no MySQL.
2. Definir as variáveis de ambiente de acordo:

   ```bash
   export DB_HOST=127.0.0.1
   export DB_USER=seu_usuario
   export DB_PASS=sua_senha
   export DB_NAME=barbearia
   ```

3. O arquivo `config/conexao.php` vai usar esses valores automaticamente.
