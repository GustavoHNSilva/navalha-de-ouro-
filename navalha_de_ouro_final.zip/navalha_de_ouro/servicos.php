<?php
require_once __DIR__ . '/config/conexao.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Serviços — Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <a href="index.php" class="logo"><img src="img/logo.png" alt="Navalha de Ouro"></a>
      <nav class="nav">
        <a href="index.php">Home</a>
        <a href="sobre.php">Sobre</a>
        <a href="servicos.php">Serviços</a>
        <a href="contato.php">Contato</a>
        <a href="agendamento.php" class="btn agendar">Agendamento</a>
      </nav>
    </div>
  </header>

  <main class="container">
    <h1>Serviços e preços</h1>
    <div class="lista-servicos">
      <article class="servico">
        <h3>Corte Masculino</h3>
        <p>Inclui lavagem, corte e finalização.</p>
        <div class="servico-actions">
          <span class="preco">R$ 60,00</span>
          <a href="agendamento.php?servico=corte" class="botao-principal">Agendar</a>
        </div>
      </article>

      <article class="servico">
        <h3>Barba</h3>
        <p>Design, navalha e finalização.</p>
        <div class="servico-actions">
          <span class="preco">R$ 40,00</span>
          <a href="agendamento.php?servico=barba" class="botao-principal">Agendar</a>
        </div>
      </article>

      <article class="servico">
        <h3>Combo Corte + Barba</h3>
        <p>Pacote com desconto.</p>
        <div class="servico-actions">
          <span class="preco">R$ 90,00</span>
          <a href="agendamento.php?servico=combo" class="botao-principal">Agendar</a>
        </div>
      </article>
    </div>
  </main>

  <footer class="site-footer">
    <div class="container">© <span id="ano4"></span> Navalha de Ouro</div>
  </footer>

  <script src="js/main.js"></script>
</body>
</html>
