<?php
require_once __DIR__ . '/config/conexao.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pega os dados do formulário
    $nome       = trim($_POST['nome'] ?? '');
    $sobrenome  = trim($_POST['sobrenome'] ?? '');
    $telefone   = trim($_POST['telefone'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $nascimento = $_POST['nascimento'] ?? null;
    $senha      = $_POST['senha'] ?? '';
    $senha_conf = $_POST['senha_confirm'] ?? '';

    // Validação simples
    if ($senha !== $senha_conf) {
        die("As senhas não conferem.");
    }

    $nome_completo = trim($nome . ' ' . $sobrenome);
    $hash = password_hash($senha, PASSWORD_DEFAULT);

    // Agora inserindo também a senha
    $sql = "INSERT INTO clientes (nome, telefone, email, data_nascimento, senha)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Erro no prepare: " . $conn->error);
    }

    $stmt->bind_param("sssss", $nome_completo, $telefone, $email, $nascimento, $hash);

    if ($stmt->execute()) {
        $_SESSION['usuario'] = [
            'id'    => $stmt->insert_id,
            'nome'  => $nome_completo,
            'email' => $email
        ];

        header('Location: painel.php');
        exit;
    } else {
        die("Erro ao inserir no banco: " . $stmt->error);
    }
}
?>

<!doctype html>
<html lang="pt-BR">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cadastro — Navalha de Ouro</title>
  <link rel="stylesheet" href="css/style.css">
</head>

<body>
  <main class="container">
    <h1>Cadastre-se</h1>
    <form method="post" id="form-cadastro">
      <label>Nome <input type="text" name="nome" required></label>
      <label>Sobrenome <input type="text" name="sobrenome" required></label>
      <label>Data de Nascimento <input type="date" name="nascimento" required></label>
      <label>Telefone <input type="tel" name="telefone" required></label>
      <label>E-mail <input type="email" name="email" required></label>
      <label>Senha <input type="password" name="senha" required minlength="8"></label>
      <label>Confirmar Senha <input type="password" name="senha_confirm" required minlength="8"></label>
      <button type="submit" class="botao-principal">Cadastrar</button>
    </form>
  </main>
</body>

</html>